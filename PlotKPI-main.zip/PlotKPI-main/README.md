Code for diplaying sites on Map with Legend of Issue column and also TXN links
